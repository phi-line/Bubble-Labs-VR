# BubbleWand_build
This is the official build for BubbleWand for free! You can purchase this game on steam but feel free to clone.

Please see my medium pages for this project. I go into detail on my UI/UX practices and the origins of this project.
https://medium.com/@phiLine/my-first-dev-blog-post-dd65fccc38f6#.9o2lsgydn
https://medium.com/@phiLine/ui-ux-design-in-bubble-labs-2d9c2731d2b2#.d9mqijukv
